﻿// Decompiled with JetBrains decompiler
// Type: Class19
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System;
using System.Collections.Generic;
using System.Management;
using System.Windows.Forms;

#nullable disable
internal static class Class19
{
  [STAThread]
  private static void Main()
  {
    Application.EnableVisualStyles();
    Application.SetCompatibleTextRenderingDefault(false);
    bool flag;
    if (flag = GClass0.smethod_0<List<string>, ManagementObjectCollection.ManagementObjectEnumerator, ManagementObject, List<string>.Enumerator, string, int, bool>())
    {
      switch (MessageBox.Show(\u003CModule\u003E.smethod_6<string>(-1219747976), \u003CModule\u003E.smethod_6<string>(240469988), MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation))
      {
        case DialogResult.OK:
          Application.Run((Form) new GForm0());
          break;
      }
    }
    else
    {
      if (flag)
        return;
      Application.Run((Form) new GForm0());
    }
  }
}
