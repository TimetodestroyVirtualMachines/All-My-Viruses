﻿// Decompiled with JetBrains decompiler
// Type: Class21
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
[CompilerGenerated]
internal sealed class Class21
{
  internal static readonly Class21.Struct6 struct6_0;

  [StructLayout(LayoutKind.Explicit, Size = 192 /*0xC0*/, Pack = 1)]
  internal struct Struct6
  {
  }
}
