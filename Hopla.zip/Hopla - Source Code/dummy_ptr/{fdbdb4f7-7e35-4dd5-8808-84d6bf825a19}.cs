﻿// Decompiled with JetBrains decompiler
// Type: dummy_ptr.{fdbdb4f7-7e35-4dd5-8808-84d6bf825a19}
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

#nullable disable
namespace dummy_ptr;

internal abstract class \u007Bfdbdb4f7\u002D7e35\u002D4dd5\u002D8808\u002D84d6bf825a19\u007D
{
  public abstract void m000040();

  public abstract void m000041();

  public abstract void m000042();

  public abstract void m000043();

  public abstract void m000044();

  public abstract void m000045();

  public abstract void m000046();

  public abstract void m000047();

  public abstract void m000048();

  public abstract void m000049();

  public abstract void m000052();

  public abstract void m000053();

  public abstract void m000054();

  public abstract void m000055();

  public abstract void m000056();

  public abstract void m000057();

  public abstract void m000058();

  public abstract void m000059();

  public abstract void m00005A();

  public abstract void m00005B();

  public abstract void m00005C();

  public abstract void m00005D();

  public abstract void m00005E();

  public abstract void m00005F();

  public abstract void m000060();

  public abstract void m000061();

  public abstract void m000062();

  public abstract void m000063();

  public abstract void m000064();

  public abstract void m000065();

  public abstract void m000066();

  public abstract void m000067();

  public abstract void m000068();

  public abstract void m000069();

  public abstract void m00006A();

  public abstract void m00006B();

  public abstract void m00006C();

  public abstract void m00006D();

  public abstract void m00006E();

  public abstract void m00006F();

  public abstract void m000070();

  public abstract void m000071();

  public abstract void m000072();

  public abstract void m000073();

  public abstract void m000074();

  public abstract void m000075();

  public abstract void m000076();

  public abstract void m000077();

  public abstract void m000078();

  public abstract void m000079();

  public abstract void m00007A();

  public abstract void m00007B();

  public abstract void m00007C();

  public abstract void m00007D();

  public abstract void m00007E();

  public abstract void m00007F();

  public abstract void m000080();

  public abstract void m000081();

  public abstract void m000082();

  public abstract void m000083();

  public abstract void m00009F();

  public abstract void m0000A0();

  public abstract void m0000A1();

  public abstract void m0000A2();

  public abstract void m0000A3();

  public abstract void m0000A4();

  public abstract void m0000A5();

  public abstract void m0000A6();

  public abstract void m0000A7();

  public abstract void m0000A8();

  public abstract void m0000A9();

  public abstract void m0000AA();

  public abstract void m0000AB();

  public abstract void m0000AC();

  public abstract void m0000AD();

  public abstract void m0000AE();

  public abstract void m0000AF();

  public abstract void m0000B0();

  public abstract void m0000B1();

  public abstract void m0000B2();

  public abstract void m0000B3();

  public abstract void m0000B4();

  public abstract void m0000B5();

  public abstract void m0000B6();

  public abstract void m0000B7();

  public abstract void m0000B8();

  public abstract void m0000B9();

  public abstract void m0000BA();

  public abstract void m0000BB();

  public abstract void m0000BC();

  public abstract void m0000BD();

  public abstract void m0000BE();

  public abstract void m0000BF();

  public abstract void m0000C0();

  public abstract void m0000C1();

  public abstract void m0000C2();

  public abstract void m0000C3();

  public abstract void m0000C4();

  public abstract void m0000C5();

  public abstract void m0000C6();

  public abstract void m0000C7();

  public abstract void m0000C8();

  public abstract void m0000C9();

  public abstract void m0000CA();

  public abstract void m0000CB();

  public abstract void m0000CC();

  public abstract void m00016A();

  public abstract void m00016B();

  public abstract void m00016C();

  public abstract void m00016D();

  public abstract void m000172();

  public abstract void m000173();

  public abstract void m000174();

  public abstract void m000178();
}
