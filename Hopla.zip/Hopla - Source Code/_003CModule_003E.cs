﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

#nullable disable
internal class \u003CModule\u003E
{
  internal static byte[] byte_0;
  internal static \u003CModule\u003E.Struct4 struct4_0;
  internal static Assembly assembly_0;
  internal static \u003CModule\u003E.Struct5 struct5_0;

  static unsafe \u003CModule\u003E()
  {
    \u003CModule\u003E.smethod_7();
    uint num1 = 192 /*0xC0*/;
    uint[] numArray1 = new uint[192 /*0xC0*/]
    {
      2380776468U,
      3981775490U,
      2624201857U,
      2508210464U,
      738078898U,
      2090817281U,
      713968832U,
      3574072966U,
      590328223U,
      1901020788U,
      682726525U,
      811617098U,
      3943125196U,
      1595741415U,
      805640163U,
      1787646000U,
      2859633365U,
      2312167019U,
      160420448U,
      1179617829U,
      2628581024U,
      165459438U,
      713836796U,
      3229919175U,
      2932421867U,
      3644364273U,
      3283103569U,
      1891424126U,
      1021882693U,
      1764494792U,
      1111879833U,
      4233479424U,
      1400519936U,
      1330754713U,
      672208376U,
      2833281861U,
      2276664333U,
      2027393407U,
      3057328475U,
      4181712995U,
      4250207017U,
      1101739159U,
      885828936U,
      106224466U,
      2195165841U,
      1602593754U,
      2166325266U,
      1868583394U,
      3131408097U,
      1938524186U,
      390350064U,
      929585149U,
      199825856U,
      3307853223U,
      2131272735U,
      18976212U,
      2436949117U,
      1429658739U,
      3313226112U,
      851219068U,
      3087781624U,
      259085035U,
      2659515844U,
      2027974955U,
      2192152993U,
      1070774561U,
      3528313223U,
      2304651961U,
      3342926954U,
      261701687U,
      509696144U,
      1175398711U,
      3899449395U,
      793312623U,
      370403078U,
      664591314U,
      419422988U,
      4046568686U,
      4068066606U,
      1386215805U,
      4256804865U,
      2876615990U,
      3711799568U,
      3115886969U,
      3724585982U,
      1623958412U,
      1887263968U,
      1339952081U,
      3125173552U,
      1715269873U,
      2887200744U,
      1044618665U,
      477366584U,
      2736447337U,
      761573754U,
      26993064U,
      4022998626U,
      2572317501U,
      2572623224U,
      1171674671U,
      215095093U,
      1954507226U,
      397537357U,
      920345385U,
      1665219413U,
      3174119017U,
      4232835260U,
      2471100456U,
      732264021U,
      3115123565U,
      1009612146U,
      255598117U,
      649713013U,
      2452867124U,
      964946674U,
      1309194374U,
      154852999U,
      1355952248U,
      533478440U,
      3421529483U,
      450163026U,
      1497579538U,
      1679921174U,
      2583193600U,
      570551508U,
      3877930420U,
      2279675665U,
      955324016U,
      1106767716U,
      3311720241U,
      3454142803U,
      1986211058U,
      3585099300U,
      2439707643U,
      3702436961U,
      987492709U,
      3569888088U,
      528293616U,
      956583408U,
      3192664675U,
      2411271400U,
      1347989258U,
      276327293U,
      244669924U,
      4058938540U,
      1573832748U,
      477237521U,
      3890211657U,
      1126841339U,
      1057615587U,
      3488254845U,
      4021912668U,
      3396473361U,
      3975190094U,
      1553208924U,
      907336015U,
      2941004629U,
      3869793000U,
      674733326U,
      3088849155U,
      2883905507U,
      2700916640U,
      2778655976U,
      1040327568U,
      915611542U,
      1857468913U,
      3955160660U,
      2654379132U,
      2997513360U,
      419165891U,
      3132721432U,
      1946195718U,
      227467012U,
      4188666808U,
      2973609680U,
      3908963184U,
      1830664334U,
      2412504870U,
      3067088303U,
      1991796872U,
      780562572U,
      1303930874U,
      2973556859U,
      2654379160U,
      2997513360U,
      419165891U,
      3132721432U,
      1946195718U,
      227467012U,
      4188666808U,
      2973609680U,
      3908963184U
    };
    uint[] numArray2 = new uint[16 /*0x10*/];
    uint num2 = 2045157933;
    for (int index = 0; index < 16 /*0x10*/; ++index)
    {
      uint num3 = num2 ^ num2 >> 12;
      uint num4 = num3 ^ num3 << 25;
      num2 = num4 ^ num4 >> 27;
      numArray2[index] = num2;
    }
    int num5 = 0;
    int num6 = 0;
    uint[] numArray3 = new uint[16 /*0x10*/];
    byte[] data = new byte[(int) num1 * 4];
    for (; (long) num5 < (long) num1; num5 += 16 /*0x10*/)
    {
      for (int index = 0; index < 16 /*0x10*/; ++index)
        numArray3[index] = numArray1[num5 + index];
      numArray3[0] = numArray3[0] ^ numArray2[0];
      numArray3[1] = numArray3[1] ^ numArray2[1];
      numArray3[2] = numArray3[2] ^ numArray2[2];
      numArray3[3] = numArray3[3] ^ numArray2[3];
      numArray3[4] = numArray3[4] ^ numArray2[4];
      numArray3[5] = numArray3[5] ^ numArray2[5];
      numArray3[6] = numArray3[6] ^ numArray2[6];
      numArray3[7] = numArray3[7] ^ numArray2[7];
      numArray3[8] = numArray3[8] ^ numArray2[8];
      numArray3[9] = numArray3[9] ^ numArray2[9];
      numArray3[10] = numArray3[10] ^ numArray2[10];
      numArray3[11] = numArray3[11] ^ numArray2[11];
      numArray3[12] = numArray3[12] ^ numArray2[12];
      numArray3[13] = numArray3[13] ^ numArray2[13];
      numArray3[14] = numArray3[14] ^ numArray2[14];
      numArray3[15] = numArray3[15] ^ numArray2[15];
      for (int index1 = 0; index1 < 16 /*0x10*/; ++index1)
      {
        uint num7 = numArray3[index1];
        byte[] numArray4 = data;
        int index2 = num6;
        int num8 = index2 + 1;
        int num9 = (int) (byte) num7;
        numArray4[index2] = (byte) num9;
        byte[] numArray5 = data;
        int index3 = num8;
        int num10 = index3 + 1;
        int num11 = (int) (byte) (num7 >> 8);
        numArray5[index3] = (byte) num11;
        byte[] numArray6 = data;
        int index4 = num10;
        int num12 = index4 + 1;
        int num13 = (int) (byte) (num7 >> 16 /*0x10*/);
        numArray6[index4] = (byte) num13;
        byte[] numArray7 = data;
        int index5 = num12;
        num6 = index5 + 1;
        int num14 = (int) (byte) (num7 >> 24);
        numArray7[index5] = (byte) num14;
        numArray2[index1] ^= num7;
      }
    }
    \u003CModule\u003E.byte_0 = \u003CModule\u003E.smethod_1(data);
    Module module = typeof (\u003CModule\u003E).Module;
    byte* hinstance = (byte*) (void*) Marshal.GetHINSTANCE(module);
    byte* numPtr1 = hinstance + 60;
    byte* numPtr2 = hinstance + *(uint*) numPtr1 + 6;
    ushort length = *(ushort*) numPtr2;
    byte* numPtr3 = numPtr2 + 14;
    ushort num15 = *(ushort*) numPtr3;
    byte* numPtr4 = numPtr3 + 4 + (int) num15;
    byte* numPtr5 = stackalloc byte[11];
    MethodInfo method;
    if (module.FullyQualifiedName[0] == '<')
    {
      uint num16 = *(uint*) (numPtr4 - 16 /*0x10*/);
      uint num17 = *(uint*) (numPtr4 - 120);
      uint[] numArray8 = new uint[(int) length];
      uint[] numArray9 = new uint[(int) length];
      uint[] numArray10 = new uint[(int) length];
      for (int index = 0; index < (int) length; ++index)
      {
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(numPtr4, 8, 64U /*0x40*/, (uint&) ref method);
        Marshal.Copy(new byte[8], 0, (IntPtr) (void*) numPtr4, 8);
        numArray8[index] = *(uint*) (numPtr4 + 12);
        numArray9[index] = *(uint*) (numPtr4 + 8);
        numArray10[index] = *(uint*) (numPtr4 + 20);
        numPtr4 += 40;
      }
      if (num17 != 0U)
      {
        for (int index = 0; index < (int) length; ++index)
        {
          if (numArray8[index] <= num17 && num17 < numArray8[index] + numArray9[index])
          {
            num17 = num17 - numArray8[index] + numArray10[index];
            break;
          }
        }
        byte* numPtr6 = hinstance + num17;
        uint num18 = *(uint*) numPtr6;
        for (int index = 0; index < (int) length; ++index)
        {
          if (numArray8[index] <= num18 && num18 < numArray8[index] + numArray9[index])
          {
            num18 = num18 - numArray8[index] + numArray10[index];
            break;
          }
        }
        byte* numPtr7 = hinstance + num18;
        uint num19 = *(uint*) (numPtr6 + 12);
        for (int index = 0; index < (int) length; ++index)
        {
          if (numArray8[index] <= num19 && num19 < numArray8[index] + numArray9[index])
          {
            num19 = num19 - numArray8[index] + numArray10[index];
            break;
          }
        }
        uint num20 = *(uint*) numPtr7 + 2U;
        for (int index = 0; index < (int) length; ++index)
        {
          if (numArray8[index] <= num20 && num20 < numArray8[index] + numArray9[index])
          {
            num20 = num20 - numArray8[index] + numArray10[index];
            break;
          }
        }
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(hinstance + num19, 11, 64U /*0x40*/, (uint&) ref method);
        *(int*) numPtr5 = 1818522734;
        *(int*) (numPtr5 + 4) = 1818504812;
        *(short*) (numPtr5 + (new IntPtr(4) * 2).ToInt64()) = (short) 108;
        numPtr5[10] = (byte) 0;
        for (int index = 0; index < 11; ++index)
          (hinstance + num19)[index] = numPtr5[index];
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(hinstance + num20, 11, 64U /*0x40*/, (uint&) ref method);
        *(int*) numPtr5 = 1866691662;
        *(int*) (numPtr5 + 4) = 1852404846;
        *(short*) (numPtr5 + (new IntPtr(4) * 2).ToInt64()) = (short) 25973;
        numPtr5[10] = (byte) 0;
        for (int index = 0; index < 11; ++index)
          (hinstance + num20)[index] = numPtr5[index];
      }
      for (int index = 0; index < (int) length; ++index)
      {
        if (numArray8[index] <= num16 && num16 < numArray8[index] + numArray9[index])
        {
          num16 = num16 - numArray8[index] + numArray10[index];
          break;
        }
      }
      byte* lpAddress1 = hinstance + num16;
      // ISSUE: cast to a reference type
      \u003CModule\u003E.VirtualProtect(lpAddress1, 72, 64U /*0x40*/, (uint&) ref method);
      uint num21 = *(uint*) (lpAddress1 + 8);
      for (int index = 0; index < (int) length; ++index)
      {
        if (numArray8[index] <= num21 && num21 < numArray8[index] + numArray9[index])
        {
          num21 = num21 - numArray8[index] + numArray10[index];
          break;
        }
      }
      *(int*) lpAddress1 = 0;
      *(int*) (lpAddress1 + 4) = 0;
      *(int*) (lpAddress1 + (new IntPtr(2) * 4).ToInt64()) = 0;
      *(int*) (lpAddress1 + (new IntPtr(3) * 4).ToInt64()) = 0;
      byte* lpAddress2 = hinstance + num21;
      // ISSUE: cast to a reference type
      \u003CModule\u003E.VirtualProtect(lpAddress2, 4, 64U /*0x40*/, (uint&) ref method);
      *(int*) lpAddress2 = 0;
      byte* numPtr8 = lpAddress2 + 12;
      byte* numPtr9 = (byte*) ((long) (numPtr8 + *(uint*) numPtr8) + 7L & -4L) + 2;
      ushort num22 = (ushort) *numPtr9;
      byte* lpAddress3 = numPtr9 + 2;
      for (int index6 = 0; index6 < (int) num22; ++index6)
      {
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(lpAddress3, 8, 64U /*0x40*/, (uint&) ref method);
        lpAddress3 = lpAddress3 + 4 + 4;
        for (int index7 = 0; index7 < 8; ++index7)
        {
          // ISSUE: cast to a reference type
          \u003CModule\u003E.VirtualProtect(lpAddress3, 4, 64U /*0x40*/, (uint&) ref method);
          *lpAddress3 = (byte) 0;
          byte* numPtr10 = lpAddress3 + 1;
          if (*numPtr10 != (byte) 0)
          {
            *numPtr10 = (byte) 0;
            byte* numPtr11 = numPtr10 + 1;
            if (*numPtr11 != (byte) 0)
            {
              *numPtr11 = (byte) 0;
              byte* numPtr12 = numPtr11 + 1;
              if (*numPtr12 != (byte) 0)
              {
                *numPtr12 = (byte) 0;
                lpAddress3 = numPtr12 + 1;
              }
              else
              {
                lpAddress3 = numPtr12 + 1;
                break;
              }
            }
            else
            {
              lpAddress3 = numPtr11 + 2;
              break;
            }
          }
          else
          {
            lpAddress3 = numPtr10 + 3;
            break;
          }
        }
      }
    }
    else
    {
      byte* lpAddress4 = hinstance + *(uint*) (numPtr4 - 16 /*0x10*/);
      MethodInfo methodInfo;
      if (*(uint*) (numPtr4 - 120) != 0U)
      {
        byte* numPtr13 = hinstance + *(uint*) (numPtr4 - 120);
        byte* numPtr14 = hinstance + *(uint*) numPtr13;
        byte* lpAddress5 = hinstance + *(uint*) (numPtr13 + 12);
        byte* lpAddress6 = hinstance + *(uint*) numPtr14 + 2;
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(lpAddress5, 11, 64U /*0x40*/, (uint&) ref methodInfo);
        *(int*) numPtr5 = 1818522734;
        *(int*) (numPtr5 + 4) = 1818504812;
        *(short*) (numPtr5 + (new IntPtr(4) * 2).ToInt64()) = (short) 108;
        numPtr5[10] = (byte) 0;
        for (int index = 0; index < 11; ++index)
          lpAddress5[index] = numPtr5[index];
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(lpAddress6, 11, 64U /*0x40*/, (uint&) ref methodInfo);
        *(int*) numPtr5 = 1866691662;
        *(int*) (numPtr5 + 4) = 1852404846;
        *(short*) (numPtr5 + (new IntPtr(4) * 2).ToInt64()) = (short) 25973;
        numPtr5[10] = (byte) 0;
        for (int index = 0; index < 11; ++index)
          lpAddress6[index] = numPtr5[index];
      }
      for (int index = 0; index < (int) length; ++index)
      {
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(numPtr4, 8, 64U /*0x40*/, (uint&) ref methodInfo);
        Marshal.Copy(new byte[8], 0, (IntPtr) (void*) numPtr4, 8);
        numPtr4 += 40;
      }
      // ISSUE: cast to a reference type
      \u003CModule\u003E.VirtualProtect(lpAddress4, 72, 64U /*0x40*/, (uint&) ref methodInfo);
      byte* lpAddress7 = hinstance + *(uint*) (lpAddress4 + 8);
      *(int*) lpAddress4 = 0;
      *(int*) (lpAddress4 + 4) = 0;
      *(int*) (lpAddress4 + (new IntPtr(2) * 4).ToInt64()) = 0;
      *(int*) (lpAddress4 + (new IntPtr(3) * 4).ToInt64()) = 0;
      // ISSUE: cast to a reference type
      \u003CModule\u003E.VirtualProtect(lpAddress7, 4, 64U /*0x40*/, (uint&) ref methodInfo);
      *(int*) lpAddress7 = 0;
      byte* numPtr15 = lpAddress7 + 12;
      byte* numPtr16 = (byte*) ((long) (numPtr15 + *(uint*) numPtr15) + 7L & -4L) + 2;
      ushort num23 = (ushort) *numPtr16;
      byte* lpAddress8 = numPtr16 + 2;
      for (int index8 = 0; index8 < (int) num23; ++index8)
      {
        // ISSUE: cast to a reference type
        \u003CModule\u003E.VirtualProtect(lpAddress8, 8, 64U /*0x40*/, (uint&) ref methodInfo);
        lpAddress8 = lpAddress8 + 4 + 4;
        for (int index9 = 0; index9 < 8; ++index9)
        {
          // ISSUE: cast to a reference type
          \u003CModule\u003E.VirtualProtect(lpAddress8, 4, 64U /*0x40*/, (uint&) ref methodInfo);
          *lpAddress8 = (byte) 0;
          byte* numPtr17 = lpAddress8 + 1;
          if (*numPtr17 != (byte) 0)
          {
            *numPtr17 = (byte) 0;
            byte* numPtr18 = numPtr17 + 1;
            if (*numPtr18 != (byte) 0)
            {
              *numPtr18 = (byte) 0;
              byte* numPtr19 = numPtr18 + 1;
              if (*numPtr19 != (byte) 0)
              {
                *numPtr19 = (byte) 0;
                lpAddress8 = numPtr19 + 1;
              }
              else
              {
                lpAddress8 = numPtr19 + 1;
                break;
              }
            }
            else
            {
              lpAddress8 = numPtr18 + 2;
              break;
            }
          }
          else
          {
            lpAddress8 = numPtr17 + 3;
            break;
          }
        }
      }
    }
    method = typeof (Environment).GetMethod(\u003CModule\u003E.smethod_3<string>(-157430457), new Type[1]
    {
      typeof (string)
    });
    if ((object) method != null)
    {
      if (\u003CModule\u003E.smethod_6<string>(-1008397483).Equals(method.Invoke((object) null, new object[1]
      {
        (object) \u003CModule\u003E.smethod_5<string>(-431634986)
      })))
        Environment.FailFast((string) null);
    }
    new Thread(new ParameterizedThreadStart(\u003CModule\u003E.smethod_0))
    {
      IsBackground = true
    }.Start((object) null);
  }

  private static void smethod_0(object thread)
  {
    if (!(thread is Thread thread1))
    {
      thread1 = new Thread(new ParameterizedThreadStart(\u003CModule\u003E.smethod_0));
      thread1.IsBackground = true;
      thread1.Start((object) Thread.CurrentThread);
      Thread.Sleep(500);
    }
    while (true)
    {
      if (Debugger.IsAttached || Debugger.IsLogging())
        Environment.FailFast((string) null);
      if (!thread1.IsAlive)
        Environment.FailFast((string) null);
      Thread.Sleep(1000);
    }
  }

  [DllImport("kernel32.dll")]
  internal static extern unsafe bool VirtualProtect(
    byte* lpAddress,
    int dwSize,
    uint flNewProtect,
    out uint lpflOldProtect);

  internal static byte[] smethod_1(byte[] data)
  {
    MemoryStream inStream = new MemoryStream(data);
    \u003CModule\u003E.Class1 class1 = new \u003CModule\u003E.Class1();
    byte[] numArray = new byte[5];
    int offset1 = 0;
    while (offset1 < 5)
      offset1 += inStream.Read(numArray, offset1, 5 - offset1);
    class1.method_5(numArray);
    int offset2 = 0;
    while (offset2 < 4)
      offset2 += inStream.Read(numArray, offset2, 4 - offset2);
    if (!BitConverter.IsLittleEndian)
      Array.Reverse((Array) numArray, 0, 4);
    int int32 = BitConverter.ToInt32(numArray, 0);
    byte[] buffer = new byte[int32];
    MemoryStream outStream = new MemoryStream(buffer, true);
    long inSize = inStream.Length - 5L - 4L;
    class1.method_4((Stream) inStream, (Stream) outStream, inSize, (long) int32);
    return buffer;
  }

  internal static T smethod_2<T>(int id)
  {
    if (!Assembly.GetExecutingAssembly().Equals((object) Assembly.GetCallingAssembly()))
      return default (T);
    id = id * 63484793 ^ 192365784;
    int num1 = id >>> 30;
    id = (id & 1073741823 /*0x3FFFFFFF*/) << 2;
    T obj;
    switch (num1)
    {
      case 0:
        int num2 = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        int length = (int) \u003CModule\u003E.byte_0[id + 4] | (int) \u003CModule\u003E.byte_0[id + 5] << 8 | (int) \u003CModule\u003E.byte_0[id + 6] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 7] << 24;
        Array instance = Array.CreateInstance(typeof (T).GetElementType(), length);
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id + 8, instance, 0, num2 - 4);
        obj = (T) instance;
        break;
      case 1:
        T[] dst = new T[1];
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id, (Array) dst, 0, sizeof (T));
        obj = dst[0];
        break;
      case 2:
        int count = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        obj = (T) string.Intern(Encoding.UTF8.GetString(\u003CModule\u003E.byte_0, id + 4, count));
        break;
      default:
        obj = default (T);
        break;
    }
    return obj;
  }

  internal static T smethod_3<T>(int id)
  {
    if (!Assembly.GetExecutingAssembly().Equals((object) Assembly.GetCallingAssembly()))
      return default (T);
    id = id * 519308039 ^ -1855688207;
    int num1 = id >>> 30;
    id = (id & 1073741823 /*0x3FFFFFFF*/) << 2;
    T obj;
    switch (num1)
    {
      case 0:
        int count = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        obj = (T) string.Intern(Encoding.UTF8.GetString(\u003CModule\u003E.byte_0, id + 4, count));
        break;
      case 1:
        int num2 = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        int length = (int) \u003CModule\u003E.byte_0[id + 4] | (int) \u003CModule\u003E.byte_0[id + 5] << 8 | (int) \u003CModule\u003E.byte_0[id + 6] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 7] << 24;
        Array instance = Array.CreateInstance(typeof (T).GetElementType(), length);
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id + 8, instance, 0, num2 - 4);
        obj = (T) instance;
        break;
      case 2:
        T[] dst = new T[1];
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id, (Array) dst, 0, sizeof (T));
        obj = dst[0];
        break;
      default:
        obj = default (T);
        break;
    }
    return obj;
  }

  internal static T smethod_4<T>(int id)
  {
    if (!Assembly.GetExecutingAssembly().Equals((object) Assembly.GetCallingAssembly()))
      return default (T);
    id = id * 1490888029 ^ -1664536991;
    int num1 = id >>> 30;
    id = (id & 1073741823 /*0x3FFFFFFF*/) << 2;
    T obj;
    switch (num1)
    {
      case 0:
        int count = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        obj = (T) string.Intern(Encoding.UTF8.GetString(\u003CModule\u003E.byte_0, id + 4, count));
        break;
      case 1:
        T[] dst = new T[1];
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id, (Array) dst, 0, sizeof (T));
        obj = dst[0];
        break;
      case 2:
        int num2 = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        int length = (int) \u003CModule\u003E.byte_0[id + 4] | (int) \u003CModule\u003E.byte_0[id + 5] << 8 | (int) \u003CModule\u003E.byte_0[id + 6] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 7] << 24;
        Array instance = Array.CreateInstance(typeof (T).GetElementType(), length);
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id + 8, instance, 0, num2 - 4);
        obj = (T) instance;
        break;
      default:
        obj = default (T);
        break;
    }
    return obj;
  }

  internal static T smethod_5<T>(int id)
  {
    if (!Assembly.GetExecutingAssembly().Equals((object) Assembly.GetCallingAssembly()))
      return default (T);
    id = id * 850021547 ^ 863153659;
    int num1 = id >>> 30;
    id = (id & 1073741823 /*0x3FFFFFFF*/) << 2;
    T obj;
    switch (num1)
    {
      case 0:
        T[] dst = new T[1];
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id, (Array) dst, 0, sizeof (T));
        obj = dst[0];
        break;
      case 1:
        int num2 = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        int length = (int) \u003CModule\u003E.byte_0[id + 4] | (int) \u003CModule\u003E.byte_0[id + 5] << 8 | (int) \u003CModule\u003E.byte_0[id + 6] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 7] << 24;
        Array instance = Array.CreateInstance(typeof (T).GetElementType(), length);
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id + 8, instance, 0, num2 - 4);
        obj = (T) instance;
        break;
      case 2:
        int count = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        obj = (T) string.Intern(Encoding.UTF8.GetString(\u003CModule\u003E.byte_0, id + 4, count));
        break;
      default:
        obj = default (T);
        break;
    }
    return obj;
  }

  internal static T smethod_6<T>(int id)
  {
    if (!Assembly.GetExecutingAssembly().Equals((object) Assembly.GetCallingAssembly()))
      return default (T);
    id = id * 354123871 ^ -22827892;
    int num1 = id >>> 30;
    id = (id & 1073741823 /*0x3FFFFFFF*/) << 2;
    T obj;
    switch (num1)
    {
      case 0:
        T[] dst = new T[1];
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id, (Array) dst, 0, sizeof (T));
        obj = dst[0];
        break;
      case 1:
        int num2 = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        int length = (int) \u003CModule\u003E.byte_0[id + 4] | (int) \u003CModule\u003E.byte_0[id + 5] << 8 | (int) \u003CModule\u003E.byte_0[id + 6] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 7] << 24;
        Array instance = Array.CreateInstance(typeof (T).GetElementType(), length);
        Buffer.BlockCopy((Array) \u003CModule\u003E.byte_0, id + 8, instance, 0, num2 - 4);
        obj = (T) instance;
        break;
      case 3:
        int count = (int) \u003CModule\u003E.byte_0[id] | (int) \u003CModule\u003E.byte_0[id + 1] << 8 | (int) \u003CModule\u003E.byte_0[id + 2] << 16 /*0x10*/ | (int) \u003CModule\u003E.byte_0[id + 3] << 24;
        obj = (T) string.Intern(Encoding.UTF8.GetString(\u003CModule\u003E.byte_0, id + 4, count));
        break;
      default:
        obj = default (T);
        break;
    }
    return obj;
  }

  internal static void smethod_7()
  {
    uint num1 = 704;
    uint[] numArray1 = new uint[704]
    {
      445254598U,
      212262858U,
      3802708914U,
      3985469270U,
      563029844U,
      3832670993U,
      2311697542U,
      3111864705U,
      2307485573U,
      4232281151U,
      3597758313U,
      3675235259U,
      82920016U,
      73644957U,
      2527729053U,
      3377176713U,
      945931245U,
      4142342543U,
      2418532865U,
      2181916242U,
      3838921582U,
      1286467141U,
      3586368929U,
      2803230U,
      2826504761U,
      2328484129U,
      2742586352U,
      1424883296U,
      2090057675U,
      572052673U,
      2432726734U,
      3857865424U,
      4131072866U,
      1462644615U,
      3920768302U,
      1124552580U,
      2676656105U,
      2032548710U,
      640339764U,
      273914780U,
      61758322U,
      3946141249U,
      309766476U,
      437370189U,
      3182089257U,
      777051460U,
      2189051863U,
      2617466458U,
      887612014U,
      1888629588U,
      2329320009U,
      1065347711U,
      1870537469U,
      2169686814U,
      3625214584U,
      1993575122U,
      1515550594U,
      2141447670U,
      558203684U,
      1314955669U,
      1655143462U,
      3208919093U,
      1561151036U,
      3017315799U,
      2105583750U,
      1005234317U,
      575800755U,
      4246742779U,
      1407483953U,
      924055256U,
      1979398842U,
      321211181U,
      2718357557U,
      1258582531U,
      1691012601U,
      3204878735U,
      3966062265U,
      3050354407U,
      3571967469U,
      2115916563U,
      2543539370U,
      2597684578U,
      3606170058U,
      3206454316U,
      1422531329U,
      1691958486U,
      3894770849U,
      3006489428U,
      326583718U,
      3245568581U,
      579225101U,
      843768120U,
      4277372140U,
      2221684689U,
      1354086063U,
      3207524718U,
      3056429893U,
      1461724485U,
      3813243835U,
      3101391869U,
      2809948718U,
      1372241905U,
      3190989462U,
      3274913942U,
      788195279U,
      1983997024U,
      1762498491U,
      3837862159U,
      1486071829U,
      1696757647U,
      1655317505U,
      2979932123U,
      4083798681U,
      4050906604U,
      3799201382U,
      4026267273U,
      2670023641U,
      1686467460U,
      3653059843U,
      2588627111U,
      1286192403U,
      1659352796U,
      995939996U,
      1632594079U,
      1848485474U,
      3493289873U,
      797825772U,
      3689594783U,
      663146281U,
      3650526494U,
      1607313165U,
      1300088093U,
      2084053711U,
      1626158685U,
      1967461035U,
      1520677396U,
      1143104685U,
      3260465465U,
      3786865074U,
      3006761996U,
      1361937633U,
      3886656236U,
      499164890U,
      307254104U,
      2121614843U,
      57556170U,
      3645313312U,
      2669323783U,
      458732500U,
      4121265786U,
      1257040013U,
      265251888U,
      3558058171U,
      3274702729U,
      3270834710U,
      3799001906U,
      4245210396U,
      2144521557U,
      826481705U,
      2431122014U,
      1428257434U,
      1573465960U,
      1157081298U,
      185279510U,
      765339658U,
      2593097992U,
      2137817726U,
      1229498267U,
      3910462433U,
      399883670U,
      1865064710U,
      343097220U,
      2600531227U,
      746868708U,
      1595765842U,
      67983879U,
      3618249213U,
      3759800141U,
      1630116039U,
      2692332793U,
      2807188549U,
      2827468632U,
      2812071584U,
      1661904195U,
      2058718456U,
      4158847206U,
      3458921945U,
      3631038781U,
      3009004098U,
      2110296333U,
      3912409300U,
      1298050376U,
      2036087451U,
      4127372225U,
      3216901274U,
      962975152U,
      1335445583U,
      10625889U,
      2214827921U,
      2022126967U,
      3779245700U,
      2413075694U,
      2210771902U,
      1208842674U,
      610075145U,
      1986821674U,
      1415503608U,
      2258705130U,
      203217904U,
      4133713220U,
      301978173U,
      2598894525U,
      2266596666U,
      3795304585U,
      4146028367U,
      3123968094U,
      732149952U,
      287331966U,
      1777430267U,
      2849074889U,
      826152327U,
      494674783U,
      1525884792U,
      1852574811U,
      2947395465U,
      645123185U,
      579752158U,
      3301931242U,
      4169924275U,
      2951818273U,
      1469904536U,
      3094992294U,
      2169608626U,
      571713519U,
      2711877124U,
      3715598646U,
      249417796U,
      1499962492U,
      2645203205U,
      4252354489U,
      3024806662U,
      561181726U,
      2064340419U,
      2968469167U,
      2156905861U,
      2672651031U,
      3810928868U,
      851520596U,
      3461928653U,
      1702441729U,
      1639378990U,
      167420732U,
      472367572U,
      3041630287U,
      1134700436U,
      1441438346U,
      2000375471U,
      956785653U,
      3240320065U,
      336431349U,
      3441847444U,
      545742773U,
      2384612109U,
      4219231191U,
      2335298284U,
      1258462670U,
      2249720558U,
      3420904236U,
      3058072078U,
      2588649702U,
      3649990992U,
      3431809563U,
      1373456163U,
      3416226154U,
      2120040395U,
      2963907346U,
      917925519U,
      2683952178U,
      103631376U,
      3543441203U,
      1998166195U,
      853292740U,
      127456735U,
      3514778565U,
      2948214772U,
      1097797116U,
      1096375573U,
      2695663657U,
      4247412156U,
      1614316409U,
      2072321206U,
      1443887658U,
      2681116951U,
      3459834249U,
      1714414129U,
      1076008472U,
      788967101U,
      4140061692U,
      1338726901U,
      4266919226U,
      3423124503U,
      1303246918U,
      1467457535U,
      3303686858U,
      146438720U,
      4172084262U,
      3227647468U,
      1438136644U,
      4239428055U,
      1727966988U,
      1842375140U,
      3124017665U,
      3508451274U,
      3617389801U,
      1153247815U,
      2011720113U,
      1346738756U,
      2117249108U,
      1140617154U,
      2052925258U,
      3402192544U,
      4081918463U,
      89930881U,
      2711993736U,
      2822128515U,
      121330193U,
      1665995584U,
      3364504391U,
      4268633298U,
      3454381206U,
      3064497889U,
      600503831U,
      866249809U,
      654339923U,
      3496527370U,
      772899452U,
      1560827513U,
      2699709046U,
      531362259U,
      100787975U,
      3841612965U,
      2306395701U,
      1894536002U,
      4280685123U,
      1732886717U,
      2583013901U,
      416382460U,
      793588092U,
      1962377945U,
      3546086429U,
      2032266351U,
      1834354536U,
      218382114U,
      2585845417U,
      2873521330U,
      4259198983U,
      3297880628U,
      3147069990U,
      1254606744U,
      3493124299U,
      816980737U,
      1287685830U,
      648072932U,
      3819581051U,
      1714640747U,
      3082568722U,
      3996597508U,
      102867038U,
      1223709210U,
      2312512615U,
      1899702228U,
      3473212192U,
      940309009U,
      2870022125U,
      2576759916U,
      4088578321U,
      4206974436U,
      34324863U,
      2703573560U,
      3104994169U,
      368087981U,
      1648821263U,
      2616834829U,
      385795096U,
      64206709U,
      1059038067U,
      224989342U,
      1329420297U,
      3165287529U,
      1356526002U,
      4163248579U,
      3507076766U,
      491935803U,
      118093067U,
      4180065894U,
      3850850668U,
      3296062437U,
      3919939182U,
      1670172221U,
      3627083084U,
      2841239274U,
      1782708971U,
      701523684U,
      409900717U,
      269495478U,
      2082053035U,
      872038980U,
      3134769571U,
      2822585821U,
      1515947744U,
      2979124819U,
      39401885U,
      2990549595U,
      3491026292U,
      3319835149U,
      1447397141U,
      175853646U,
      548240737U,
      91392537U,
      3995865839U,
      4149170933U,
      2759644428U,
      2211284451U,
      1652376197U,
      3701146728U,
      701862462U,
      3938324454U,
      523545839U,
      3745212459U,
      772857611U,
      880945968U,
      784251377U,
      1616282415U,
      652187128U,
      2281024570U,
      1056517476U,
      4077060025U,
      1272942716U,
      834159192U,
      2022668073U,
      154587806U,
      1705686000U,
      2493831875U,
      2127812040U,
      3854025130U,
      101377554U,
      405837819U,
      3419676119U,
      2683839279U,
      2471896123U,
      1954541219U,
      2030878805U,
      3059345061U,
      569630652U,
      2969379713U,
      814987075U,
      2101392078U,
      1091162232U,
      4066907373U,
      1026715085U,
      2932716576U,
      3936263670U,
      2582863383U,
      439191604U,
      4056615298U,
      4195973530U,
      2142413074U,
      774081396U,
      1371810356U,
      83314595U,
      637940213U,
      116037634U,
      4031999694U,
      1983699114U,
      2862871313U,
      4238142261U,
      2054572983U,
      1854053963U,
      2690983005U,
      3808667402U,
      3457028372U,
      1843985500U,
      4108621701U,
      3118184702U,
      2070675183U,
      813243722U,
      4095529271U,
      3998528249U,
      528949192U,
      3765081982U,
      3032041519U,
      354914801U,
      2274464950U,
      1203272675U,
      1869301825U,
      278968911U,
      3949747233U,
      4107518609U,
      3987575069U,
      24306672U,
      1355142318U,
      648508901U,
      1801297628U,
      4206265603U,
      3924819474U,
      2581739972U,
      2810603515U,
      3261404380U,
      1744122393U,
      4002866638U,
      3814954873U,
      3738920140U,
      2023287167U,
      191132584U,
      813140720U,
      4022382934U,
      2335034028U,
      3873358899U,
      2200732862U,
      2746484375U,
      3284686085U,
      1526332085U,
      3359803232U,
      3592051100U,
      1273176501U,
      3539958983U,
      3344966386U,
      3703677671U,
      562844567U,
      3206974088U,
      4243303614U,
      3563875701U,
      1047976250U,
      2186271460U,
      3901449114U,
      987281274U,
      861432301U,
      3117291331U,
      532996224U,
      619194286U,
      1264693922U,
      1778816220U,
      631810262U,
      2011590793U,
      2296693560U,
      944275044U,
      3163901268U,
      2850803239U,
      342765358U,
      433949067U,
      686282424U,
      2585943478U,
      5960690U,
      3758673768U,
      890213089U,
      39127758U,
      2915456244U,
      3291585001U,
      4098909664U,
      2690136685U,
      2338382597U,
      3691429528U,
      3337227474U,
      1334879728U,
      344304170U,
      4275928649U,
      136829996U,
      3341972094U,
      458780702U,
      3749571916U,
      2584043079U,
      2453928257U,
      1752960713U,
      1182544521U,
      3888193140U,
      1084639972U,
      1858070037U,
      3387181514U,
      4180266348U,
      1181418152U,
      3535745400U,
      1930823490U,
      1519241503U,
      2910237917U,
      173368836U,
      3634052500U,
      890421559U,
      4271893644U,
      45565495U,
      2528912272U,
      1655877155U,
      79734389U,
      4081740014U,
      3647845322U,
      2303155328U,
      868078884U,
      4168221215U,
      4271934155U,
      770396774U,
      4209284918U,
      2725125516U,
      3828712397U,
      1334180015U,
      2119503253U,
      79337345U,
      3292946325U,
      2575443081U,
      2207782779U,
      2053785922U,
      443543282U,
      2680648912U,
      2702539901U,
      2541183721U,
      3513596600U,
      1895980429U,
      887059272U,
      1504631922U,
      1268865949U,
      26713118U,
      4055984696U,
      1814805789U,
      1955906734U,
      3516085931U,
      3994217560U,
      2688388968U,
      3350344333U,
      2239628561U,
      944676483U,
      4087795645U,
      3395311264U,
      2129056792U,
      2520164377U,
      3779153544U,
      3558843409U,
      1738415195U,
      859003236U,
      1337238774U,
      3169302035U,
      2188437719U,
      1556934080U,
      1944922107U,
      3244582542U,
      1487366653U,
      804101830U,
      42794264U,
      3698531607U,
      3982112358U,
      3795628316U,
      2826538807U,
      2531051925U,
      2560836306U,
      3823861336U,
      560009343U,
      3565327838U,
      3467855009U,
      2450512801U,
      380515810U,
      1873645169U,
      1203178222U,
      2954029566U,
      350290762U,
      308567857U,
      2337808395U,
      2677975078U,
      1889081523U,
      2256275369U,
      1705166127U,
      2314837684U,
      751223044U,
      2261189141U,
      357389552U,
      537251770U,
      131502723U,
      2979187399U,
      4226855474U,
      304136511U,
      4051974849U,
      440912005U,
      3537472363U,
      442877455U,
      3208541669U,
      1897157012U,
      3546033760U,
      1182907764U,
      3420805345U,
      3946549386U,
      455539728U,
      1890264024U,
      111042905U,
      405970823U,
      1889983792U,
      878532300U,
      4182160704U,
      1748580881U,
      2859120818U,
      476554679U,
      1153392152U,
      1897157012U,
      3546033760U,
      1182907764U,
      3420805345U,
      3946549386U,
      455539728U,
      1890264024U
    };
    uint[] numArray2 = new uint[16 /*0x10*/];
    uint num2 = 2324586490;
    for (int index = 0; index < 16 /*0x10*/; ++index)
    {
      uint num3 = num2 ^ num2 >> 13;
      uint num4 = num3 ^ num3 << 25;
      num2 = num4 ^ num4 >> 27;
      numArray2[index] = num2;
    }
    int num5 = 0;
    int num6 = 0;
    uint[] numArray3 = new uint[16 /*0x10*/];
    byte[] data = new byte[(int) num1 * 4];
    for (; (long) num5 < (long) num1; num5 += 16 /*0x10*/)
    {
      for (int index = 0; index < 16 /*0x10*/; ++index)
        numArray3[index] = numArray1[num5 + index];
      numArray3[0] = numArray3[0] ^ numArray2[0];
      numArray3[1] = numArray3[1] ^ numArray2[1];
      numArray3[2] = numArray3[2] ^ numArray2[2];
      numArray3[3] = numArray3[3] ^ numArray2[3];
      numArray3[4] = numArray3[4] ^ numArray2[4];
      numArray3[5] = numArray3[5] ^ numArray2[5];
      numArray3[6] = numArray3[6] ^ numArray2[6];
      numArray3[7] = numArray3[7] ^ numArray2[7];
      numArray3[8] = numArray3[8] ^ numArray2[8];
      numArray3[9] = numArray3[9] ^ numArray2[9];
      numArray3[10] = numArray3[10] ^ numArray2[10];
      numArray3[11] = numArray3[11] ^ numArray2[11];
      numArray3[12] = numArray3[12] ^ numArray2[12];
      numArray3[13] = numArray3[13] ^ numArray2[13];
      numArray3[14] = numArray3[14] ^ numArray2[14];
      numArray3[15] = numArray3[15] ^ numArray2[15];
      for (int index1 = 0; index1 < 16 /*0x10*/; ++index1)
      {
        uint num7 = numArray3[index1];
        byte[] numArray4 = data;
        int index2 = num6;
        int num8 = index2 + 1;
        int num9 = (int) (byte) num7;
        numArray4[index2] = (byte) num9;
        byte[] numArray5 = data;
        int index3 = num8;
        int num10 = index3 + 1;
        int num11 = (int) (byte) (num7 >> 8);
        numArray5[index3] = (byte) num11;
        byte[] numArray6 = data;
        int index4 = num10;
        int num12 = index4 + 1;
        int num13 = (int) (byte) (num7 >> 16 /*0x10*/);
        numArray6[index4] = (byte) num13;
        byte[] numArray7 = data;
        int index5 = num12;
        num6 = index5 + 1;
        int num14 = (int) (byte) (num7 >> 24);
        numArray7[index5] = (byte) num14;
        numArray2[index1] ^= num7;
      }
    }
    \u003CModule\u003E.assembly_0 = Assembly.Load(\u003CModule\u003E.smethod_1(data));
    AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(\u003CModule\u003E.smethod_8);
  }

  internal static Assembly smethod_8(object sender, ResolveEventArgs args)
  {
    return \u003CModule\u003E.assembly_0.FullName == args.Name ? \u003CModule\u003E.assembly_0 : (Assembly) null;
  }

  [DllImport("kernel32.dll", EntryPoint = "VirtualProtect")]
  internal static extern bool VirtualProtect_1(
    IntPtr lpAddress,
    uint dwSize,
    uint flNewProtect,
    out uint lpflOldProtect);

  internal static unsafe void smethod_9()
  {
    Module module = typeof (\u003CModule\u003E).Module;
    string fullyQualifiedName = module.FullyQualifiedName;
    bool flag = fullyQualifiedName.Length > 0 && fullyQualifiedName[0] == '<';
    byte* hinstance = (byte*) (void*) Marshal.GetHINSTANCE(module);
    byte* numPtr1 = hinstance + *(uint*) (hinstance + 60);
    ushort num1 = *(ushort*) (numPtr1 + 6);
    ushort num2 = *(ushort*) (numPtr1 + 20);
    uint* lpAddress = (uint*) null;
    uint num3 = 0;
    uint* numPtr2 = (uint*) (numPtr1 + 24 + (int) num2);
    uint num4 = 1844709190;
    uint num5 = 1724579677;
    uint num6 = 376028211;
    uint num7 = 1623054120;
    for (int index1 = 0; index1 < (int) num1; ++index1)
    {
      uint* numPtr3 = numPtr2;
      uint* numPtr4 = (uint*) ((IntPtr) numPtr3 + 4);
      int num8 = (int) *numPtr3;
      uint* numPtr5 = numPtr4;
      uint* numPtr6 = (uint*) ((IntPtr) numPtr5 + 4);
      int num9 = (int) *numPtr5;
      switch ((uint) (num8 * num9))
      {
        case 0:
          numPtr2 = numPtr6 + 8;
          continue;
        case 872394698:
          lpAddress = (uint*) (hinstance + (flag ? numPtr6[3] : numPtr6[1]));
          num3 = (uint) ((flag ? (int) numPtr6[2] : (int) *numPtr6) >>> 2);
          goto case 0;
        default:
          uint* numPtr7 = (uint*) (hinstance + (flag ? numPtr6[3] : numPtr6[1]));
          uint num10 = numPtr6[2] >> 2;
          for (uint index2 = 0; index2 < num10; ++index2)
          {
            int num11 = ((int) num4 ^ (int) *numPtr7++) + (int) num5 + (int) num6 * (int) num7;
            num4 = num5;
            num5 = num7;
            num7 = (uint) num11;
          }
          goto case 0;
      }
    }
    uint[] numArray1 = new uint[16 /*0x10*/];
    uint[] numArray2 = new uint[16 /*0x10*/];
    for (int index = 0; index < 16 /*0x10*/; ++index)
    {
      numArray1[index] = num7;
      numArray2[index] = num5;
      uint num12 = num5 >> 5 | num5 << 27;
      num5 = num6 >> 3 | num6 << 29;
      num6 = num7 >> 7 | num7 << 25;
      num7 = num12 >> 11 | num12 << 21;
    }
    numArray1[0] = numArray1[0] ^ numArray2[0];
    numArray1[1] = numArray1[1] * numArray2[1];
    numArray1[2] = numArray1[2] + numArray2[2];
    numArray1[3] = numArray1[3] ^ numArray2[3];
    numArray1[4] = numArray1[4] * numArray2[4];
    numArray1[5] = numArray1[5] + numArray2[5];
    numArray1[6] = numArray1[6] ^ numArray2[6];
    numArray1[7] = numArray1[7] * numArray2[7];
    numArray1[8] = numArray1[8] + numArray2[8];
    numArray1[9] = numArray1[9] ^ numArray2[9];
    numArray1[10] = numArray1[10] * numArray2[10];
    numArray1[11] = numArray1[11] + numArray2[11];
    numArray1[12] = numArray1[12] ^ numArray2[12];
    numArray1[13] = numArray1[13] * numArray2[13];
    numArray1[14] = numArray1[14] + numArray2[14];
    numArray1[15] = numArray1[15] ^ numArray2[15];
    uint lpflOldProtect = 64 /*0x40*/;
    \u003CModule\u003E.VirtualProtect_1((IntPtr) (void*) lpAddress, num3 << 2, 64U /*0x40*/, out lpflOldProtect);
    if (lpflOldProtect == 64U /*0x40*/)
      return;
    uint num13 = 0;
    for (uint index = 0; index < num3; ++index)
    {
      uint* numPtr8 = lpAddress;
      int num14 = (int) *numPtr8 ^ (int) numArray1[(int) num13 & 15];
      *numPtr8 = (uint) num14;
      numArray1[(int) num13 & 15] = (uint) (((int) numArray1[(int) num13 & 15] ^ (int) *lpAddress++) + 1035675673);
      ++num13;
    }
  }

  internal struct Struct0
  {
    internal uint uint_0;

    internal void method_0() => this.uint_0 = 1024U /*0x0400*/;

    internal uint method_1(\u003CModule\u003E.Class0 rangeDecoder)
    {
      uint num = (rangeDecoder.uint_1 >> 11) * this.uint_0;
      if (rangeDecoder.uint_0 >= num)
      {
        rangeDecoder.uint_1 -= num;
        rangeDecoder.uint_0 -= num;
        this.uint_0 -= this.uint_0 >> 5;
        if (rangeDecoder.uint_1 < 16777216U /*0x01000000*/)
        {
          rangeDecoder.uint_0 = rangeDecoder.uint_0 << 8 | (uint) (byte) rangeDecoder.stream_0.ReadByte();
          rangeDecoder.uint_1 <<= 8;
        }
        return 1;
      }
      rangeDecoder.uint_1 = num;
      this.uint_0 += 2048U /*0x0800*/ - this.uint_0 >> 5;
      if (rangeDecoder.uint_1 < 16777216U /*0x01000000*/)
      {
        rangeDecoder.uint_0 = rangeDecoder.uint_0 << 8 | (uint) (byte) rangeDecoder.stream_0.ReadByte();
        rangeDecoder.uint_1 <<= 8;
      }
      return 0;
    }
  }

  internal struct Struct1
  {
    internal readonly \u003CModule\u003E.Struct0[] struct0_0;
    internal readonly int int_0;

    internal Struct1(int numBitLevels)
    {
      this.int_0 = numBitLevels;
      this.struct0_0 = new \u003CModule\u003E.Struct0[1 << numBitLevels];
    }

    internal void method_0()
    {
      for (uint index = 1; (long) index < (long) (1 << this.int_0); ++index)
        this.struct0_0[(int) index].method_0();
    }

    internal uint method_1(\u003CModule\u003E.Class0 rangeDecoder)
    {
      uint index = 1;
      for (int int0 = this.int_0; int0 > 0; --int0)
        index = (index << 1) + this.struct0_0[(int) index].method_1(rangeDecoder);
      return index - (uint) (1 << this.int_0);
    }

    internal uint method_2(\u003CModule\u003E.Class0 rangeDecoder)
    {
      uint index1 = 1;
      uint num1 = 0;
      for (int index2 = 0; index2 < this.int_0; ++index2)
      {
        uint num2 = this.struct0_0[(int) index1].method_1(rangeDecoder);
        index1 = (index1 << 1) + num2;
        num1 |= num2 << index2;
      }
      return num1;
    }

    internal static uint smethod_0(
      \u003CModule\u003E.Struct0[] Models,
      uint startIndex,
      \u003CModule\u003E.Class0 rangeDecoder,
      int NumBitLevels)
    {
      uint num1 = 1;
      uint num2 = 0;
      for (int index = 0; index < NumBitLevels; ++index)
      {
        uint num3 = Models[(int) startIndex + (int) num1].method_1(rangeDecoder);
        num1 = (num1 << 1) + num3;
        num2 |= num3 << index;
      }
      return num2;
    }
  }

  internal class Class0
  {
    internal uint uint_0;
    internal uint uint_1;
    internal Stream stream_0;

    internal void method_0(Stream stream)
    {
      this.stream_0 = stream;
      this.uint_0 = 0U;
      this.uint_1 = uint.MaxValue;
      for (int index = 0; index < 5; ++index)
        this.uint_0 = this.uint_0 << 8 | (uint) (byte) this.stream_0.ReadByte();
    }

    internal void method_1() => this.stream_0 = (Stream) null;

    internal void method_2()
    {
      for (; this.uint_1 < 16777216U /*0x01000000*/; this.uint_1 <<= 8)
        this.uint_0 = this.uint_0 << 8 | (uint) (byte) this.stream_0.ReadByte();
    }

    internal uint method_3(int numTotalBits)
    {
      uint uint1 = this.uint_1;
      uint num1 = this.uint_0;
      uint num2 = 0;
      for (int index = numTotalBits; index > 0; --index)
      {
        uint1 >>= 1;
        uint num3 = num1 - uint1 >> 31 /*0x1F*/;
        num1 -= uint1 & num3 - 1U;
        num2 = (uint) ((int) num2 << 1 | 1 - (int) num3);
        if (uint1 < 16777216U /*0x01000000*/)
        {
          num1 = num1 << 8 | (uint) (byte) this.stream_0.ReadByte();
          uint1 <<= 8;
        }
      }
      this.uint_1 = uint1;
      this.uint_0 = num1;
      return num2;
    }

    internal Class0()
    {
    }
  }

  internal class Class1
  {
    internal readonly \u003CModule\u003E.Struct0[] struct0_0 = new \u003CModule\u003E.Struct0[192 /*0xC0*/];
    internal readonly \u003CModule\u003E.Struct0[] struct0_1 = new \u003CModule\u003E.Struct0[192 /*0xC0*/];
    internal readonly \u003CModule\u003E.Struct0[] struct0_2 = new \u003CModule\u003E.Struct0[12];
    internal readonly \u003CModule\u003E.Struct0[] struct0_3 = new \u003CModule\u003E.Struct0[12];
    internal readonly \u003CModule\u003E.Struct0[] struct0_4 = new \u003CModule\u003E.Struct0[12];
    internal readonly \u003CModule\u003E.Struct0[] struct0_5 = new \u003CModule\u003E.Struct0[12];
    internal readonly \u003CModule\u003E.Class1.Class2 class2_0 = new \u003CModule\u003E.Class1.Class2();
    internal readonly \u003CModule\u003E.Class1.Class3 class3_0 = new \u003CModule\u003E.Class1.Class3();
    internal readonly \u003CModule\u003E.Class4 class4_0 = new \u003CModule\u003E.Class4();
    internal readonly \u003CModule\u003E.Struct0[] struct0_6 = new \u003CModule\u003E.Struct0[114];
    internal readonly \u003CModule\u003E.Struct1[] struct1_0 = new \u003CModule\u003E.Struct1[4];
    internal readonly \u003CModule\u003E.Class0 class0_0 = new \u003CModule\u003E.Class0();
    internal readonly \u003CModule\u003E.Class1.Class2 class2_1 = new \u003CModule\u003E.Class1.Class2();
    internal bool bool_0;
    internal uint uint_0;
    internal uint uint_1;
    internal \u003CModule\u003E.Struct1 struct1_1 = new \u003CModule\u003E.Struct1(4);
    internal uint uint_2;

    internal Class1()
    {
      this.uint_0 = uint.MaxValue;
      for (int index = 0; index < 4; ++index)
        this.struct1_0[index] = new \u003CModule\u003E.Struct1(6);
    }

    internal void method_0(uint dictionarySize)
    {
      if ((int) this.uint_0 == (int) dictionarySize)
        return;
      this.uint_0 = dictionarySize;
      this.uint_1 = Math.Max(this.uint_0, 1U);
      this.class4_0.method_0(Math.Max(this.uint_1, 4096U /*0x1000*/));
    }

    internal void method_1(int lp, int lc) => this.class3_0.method_0(lp, lc);

    internal void method_2(int pb)
    {
      uint numPosStates = (uint) (1 << pb);
      this.class2_0.method_0(numPosStates);
      this.class2_1.method_0(numPosStates);
      this.uint_2 = numPosStates - 1U;
    }

    internal void method_3(Stream inStream, Stream outStream)
    {
      this.class0_0.method_0(inStream);
      this.class4_0.method_1(outStream, this.bool_0);
      for (uint index1 = 0; index1 < 12U; ++index1)
      {
        for (uint index2 = 0; index2 <= this.uint_2; ++index2)
        {
          uint index3 = (index1 << 4) + index2;
          this.struct0_0[(int) index3].method_0();
          this.struct0_1[(int) index3].method_0();
        }
        this.struct0_2[(int) index1].method_0();
        this.struct0_3[(int) index1].method_0();
        this.struct0_4[(int) index1].method_0();
        this.struct0_5[(int) index1].method_0();
      }
      this.class3_0.method_1();
      for (uint index = 0; index < 4U; ++index)
        this.struct1_0[(int) index].method_0();
      for (uint index = 0; index < 114U; ++index)
        this.struct0_6[(int) index].method_0();
      this.class2_0.method_1();
      this.class2_1.method_1();
      this.struct1_1.method_0();
    }

    internal void method_4(Stream inStream, Stream outStream, long inSize, long outSize)
    {
      this.method_3(inStream, outStream);
      \u003CModule\u003E.Struct3 struct3 = new \u003CModule\u003E.Struct3();
      struct3.method_0();
      uint distance = 0;
      uint num1 = 0;
      uint num2 = 0;
      uint num3 = 0;
      ulong pos = 0;
      ulong num4 = (ulong) outSize;
      if (0UL < num4)
      {
        int num5 = (int) this.struct0_0[(int) struct3.uint_0 << 4].method_1(this.class0_0);
        struct3.method_1();
        this.class4_0.method_5(this.class3_0.method_3(this.class0_0, 0U, (byte) 0));
        ++pos;
      }
      while (pos < num4)
      {
        uint posState = (uint) pos & this.uint_2;
        if (this.struct0_0[((int) struct3.uint_0 << 4) + (int) posState].method_1(this.class0_0) != 0U)
        {
          uint len;
          if (this.struct0_2[(int) struct3.uint_0].method_1(this.class0_0) == 1U)
          {
            if (this.struct0_3[(int) struct3.uint_0].method_1(this.class0_0) != 0U)
            {
              uint num6;
              if (this.struct0_4[(int) struct3.uint_0].method_1(this.class0_0) == 0U)
              {
                num6 = num1;
              }
              else
              {
                if (this.struct0_5[(int) struct3.uint_0].method_1(this.class0_0) == 0U)
                {
                  num6 = num2;
                }
                else
                {
                  num6 = num3;
                  num3 = num2;
                }
                num2 = num1;
              }
              num1 = distance;
              distance = num6;
            }
            else if (this.struct0_1[((int) struct3.uint_0 << 4) + (int) posState].method_1(this.class0_0) == 0U)
            {
              struct3.method_4();
              this.class4_0.method_5(this.class4_0.method_6(distance));
              ++pos;
              continue;
            }
            len = this.class2_1.method_2(this.class0_0, posState) + 2U;
            struct3.method_3();
          }
          else
          {
            num3 = num2;
            num2 = num1;
            num1 = distance;
            len = 2U + this.class2_0.method_2(this.class0_0, posState);
            struct3.method_2();
            uint num7 = this.struct1_0[(int) \u003CModule\u003E.Class1.smethod_0(len)].method_1(this.class0_0);
            if (num7 < 4U)
            {
              distance = num7;
            }
            else
            {
              int NumBitLevels = (int) (num7 >> 1) - 1;
              uint num8 = (uint) ((2 | (int) num7 & 1) << NumBitLevels);
              distance = num7 < 14U ? num8 + \u003CModule\u003E.Struct1.smethod_0(this.struct0_6, (uint) ((int) num8 - (int) num7 - 1), this.class0_0, NumBitLevels) : num8 + (this.class0_0.method_3(NumBitLevels - 4) << 4) + this.struct1_1.method_2(this.class0_0);
            }
          }
          if ((ulong) distance < pos && distance < this.uint_1 || distance != uint.MaxValue)
          {
            this.class4_0.method_4(distance, len);
            pos += (ulong) len;
          }
          else
            break;
        }
        else
        {
          byte prevByte = this.class4_0.method_6(0U);
          this.class4_0.method_5(!struct3.method_5() ? this.class3_0.method_4(this.class0_0, (uint) pos, prevByte, this.class4_0.method_6(distance)) : this.class3_0.method_3(this.class0_0, (uint) pos, prevByte));
          struct3.method_1();
          ++pos;
        }
      }
      this.class4_0.method_3();
      this.class4_0.method_2();
      this.class0_0.method_1();
    }

    internal void method_5(byte[] properties)
    {
      int lc = (int) properties[0] % 9;
      int num = (int) properties[0] / 9;
      int lp = num % 5;
      int pb = num / 5;
      uint dictionarySize = 0;
      for (int index = 0; index < 4; ++index)
        dictionarySize += (uint) properties[1 + index] << index * 8;
      this.method_0(dictionarySize);
      this.method_1(lp, lc);
      this.method_2(pb);
    }

    internal static uint smethod_0(uint len)
    {
      len -= 2U;
      return len < 4U ? len : 3U;
    }

    internal class Class2
    {
      internal readonly \u003CModule\u003E.Struct1[] struct1_0 = new \u003CModule\u003E.Struct1[16 /*0x10*/];
      internal readonly \u003CModule\u003E.Struct1[] struct1_1 = new \u003CModule\u003E.Struct1[16 /*0x10*/];
      internal \u003CModule\u003E.Struct0 struct0_0;
      internal \u003CModule\u003E.Struct0 struct0_1;
      internal \u003CModule\u003E.Struct1 struct1_2 = new \u003CModule\u003E.Struct1(8);
      internal uint uint_0;

      internal void method_0(uint numPosStates)
      {
        for (uint uint0 = this.uint_0; uint0 < numPosStates; ++uint0)
        {
          this.struct1_0[(int) uint0] = new \u003CModule\u003E.Struct1(3);
          this.struct1_1[(int) uint0] = new \u003CModule\u003E.Struct1(3);
        }
        this.uint_0 = numPosStates;
      }

      internal void method_1()
      {
        this.struct0_0.method_0();
        for (uint index = 0; index < this.uint_0; ++index)
        {
          this.struct1_0[(int) index].method_0();
          this.struct1_1[(int) index].method_0();
        }
        this.struct0_1.method_0();
        this.struct1_2.method_0();
      }

      internal uint method_2(\u003CModule\u003E.Class0 rangeDecoder, uint posState)
      {
        if (this.struct0_0.method_1(rangeDecoder) == 0U)
          return this.struct1_0[(int) posState].method_1(rangeDecoder);
        uint num = 8;
        return this.struct0_1.method_1(rangeDecoder) == 0U ? num + this.struct1_1[(int) posState].method_1(rangeDecoder) : num + 8U + this.struct1_2.method_1(rangeDecoder);
      }

      internal Class2()
      {
      }
    }

    internal class Class3
    {
      internal \u003CModule\u003E.Class1.Class3.Struct2[] struct2_0;
      internal int int_0;
      internal int int_1;
      internal uint uint_0;

      internal void method_0(int numPosBits, int numPrevBits)
      {
        if (this.struct2_0 != null && this.int_1 == numPrevBits && this.int_0 == numPosBits)
          return;
        this.int_0 = numPosBits;
        this.uint_0 = (uint) ((1 << numPosBits) - 1);
        this.int_1 = numPrevBits;
        uint length = (uint) (1 << this.int_1 + this.int_0);
        this.struct2_0 = new \u003CModule\u003E.Class1.Class3.Struct2[(int) length];
        for (uint index = 0; index < length; ++index)
          this.struct2_0[(int) index].method_0();
      }

      internal void method_1()
      {
        uint num = (uint) (1 << this.int_1 + this.int_0);
        for (uint index = 0; index < num; ++index)
          this.struct2_0[(int) index].method_1();
      }

      internal uint method_2(uint pos, byte prevByte)
      {
        return (uint) ((((int) pos & (int) this.uint_0) << this.int_1) + ((int) prevByte >> 8 - this.int_1));
      }

      internal byte method_3(\u003CModule\u003E.Class0 rangeDecoder, uint pos, byte prevByte)
      {
        return this.struct2_0[(int) this.method_2(pos, prevByte)].method_2(rangeDecoder);
      }

      internal byte method_4(
        \u003CModule\u003E.Class0 rangeDecoder,
        uint pos,
        byte prevByte,
        byte matchByte)
      {
        return this.struct2_0[(int) this.method_2(pos, prevByte)].method_3(rangeDecoder, matchByte);
      }

      internal Class3()
      {
      }

      internal struct Struct2
      {
        internal \u003CModule\u003E.Struct0[] struct0_0;

        internal void method_0() => this.struct0_0 = new \u003CModule\u003E.Struct0[768 /*0x0300*/];

        internal void method_1()
        {
          for (int index = 0; index < 768 /*0x0300*/; ++index)
            this.struct0_0[index].method_0();
        }

        internal byte method_2(\u003CModule\u003E.Class0 rangeDecoder)
        {
          uint index = 1;
          do
          {
            index = index << 1 | this.struct0_0[(int) index].method_1(rangeDecoder);
          }
          while (index < 256U /*0x0100*/);
          return (byte) index;
        }

        internal byte method_3(\u003CModule\u003E.Class0 rangeDecoder, byte matchByte)
        {
          uint index = 1;
          do
          {
            uint num1 = (uint) ((int) matchByte >> 7 & 1);
            matchByte <<= 1;
            uint num2 = this.struct0_0[(1 + (int) num1 << 8) + (int) index].method_1(rangeDecoder);
            index = index << 1 | num2;
            if ((int) num1 != (int) num2)
              goto label_4;
          }
          while (index < 256U /*0x0100*/);
          goto label_5;
label_4:
          while (index < 256U /*0x0100*/)
            index = index << 1 | this.struct0_0[(int) index].method_1(rangeDecoder);
label_5:
          return (byte) index;
        }
      }
    }
  }

  internal class Class4
  {
    internal byte[] byte_0;
    internal uint uint_0;
    internal Stream stream_0;
    internal uint uint_1;
    internal uint uint_2;

    internal void method_0(uint windowSize)
    {
      if ((int) this.uint_2 != (int) windowSize)
        this.byte_0 = new byte[(int) windowSize];
      this.uint_2 = windowSize;
      this.uint_0 = 0U;
      this.uint_1 = 0U;
    }

    internal void method_1(Stream stream, bool solid)
    {
      this.method_2();
      this.stream_0 = stream;
      if (solid)
        return;
      this.uint_1 = 0U;
      this.uint_0 = 0U;
    }

    internal void method_2()
    {
      this.method_3();
      this.stream_0 = (Stream) null;
      Buffer.BlockCopy((Array) new byte[this.byte_0.Length], 0, (Array) this.byte_0, 0, this.byte_0.Length);
    }

    internal void method_3()
    {
      uint count = this.uint_0 - this.uint_1;
      if (count == 0U)
        return;
      this.stream_0.Write(this.byte_0, (int) this.uint_1, (int) count);
      if (this.uint_0 >= this.uint_2)
        this.uint_0 = 0U;
      this.uint_1 = this.uint_0;
    }

    internal void method_4(uint distance, uint len)
    {
      uint num = (uint) ((int) this.uint_0 - (int) distance - 1);
      if (num >= this.uint_2)
        num += this.uint_2;
      for (; len > 0U; --len)
      {
        if (num >= this.uint_2)
          num = 0U;
        this.byte_0[(int) this.uint_0++] = this.byte_0[(int) num++];
        if (this.uint_0 >= this.uint_2)
          this.method_3();
      }
    }

    internal void method_5(byte b)
    {
      this.byte_0[(int) this.uint_0++] = b;
      if (this.uint_0 < this.uint_2)
        return;
      this.method_3();
    }

    internal byte method_6(uint distance)
    {
      uint index = (uint) ((int) this.uint_0 - (int) distance - 1);
      if (index >= this.uint_2)
        index += this.uint_2;
      return this.byte_0[(int) index];
    }

    internal Class4()
    {
    }
  }

  internal struct Struct3
  {
    internal uint uint_0;

    internal void method_0() => this.uint_0 = 0U;

    internal void method_1()
    {
      if (this.uint_0 < 4U)
        this.uint_0 = 0U;
      else if (this.uint_0 >= 10U)
        this.uint_0 -= 6U;
      else
        this.uint_0 -= 3U;
    }

    internal void method_2() => this.uint_0 = this.uint_0 < 7U ? 7U : 10U;

    internal void method_3() => this.uint_0 = this.uint_0 < 7U ? 8U : 11U;

    internal void method_4() => this.uint_0 = this.uint_0 < 7U ? 9U : 11U;

    internal bool method_5() => this.uint_0 < 7U;
  }

  [StructLayout(LayoutKind.Explicit, Size = 768 /*0x0300*/)]
  internal struct Struct4
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 2816 /*0x0B00*/, Pack = 1)]
  internal struct Struct5
  {
  }
}
