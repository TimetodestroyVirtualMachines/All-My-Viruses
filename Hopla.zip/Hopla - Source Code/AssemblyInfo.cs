﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright © TimetodestroyVirtualMachines 2026")]
[assembly: AssemblyProduct("Hopla Trojan")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("239f87d9-4abf-44e1-96b7-a00ca6ceb319")]
[assembly: AssemblyCompany("TimetodestroyVirtualMachines")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Hopla Trojan - MEMZ Remake")]
[assembly: AssemblyTitle("Hopla Trojan")]
[assembly: AssemblyVersion("1.0.0.0")]
