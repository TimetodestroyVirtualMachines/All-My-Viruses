﻿// Decompiled with JetBrains decompiler
// Type: GForm0
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
public class GForm0 : Form
{
  private static readonly ushort[] ushort_0 = new ushort[96 /*0x60*/]
  {
    (ushort) 62226,
    (ushort) 62245,
    (ushort) 62237,
    (ushort) 62235,
    (ushort) 62225,
    (ushort) 62220,
    (ushort) 62222,
    (ushort) 54302,
    (ushort) 62231,
    (ushort) 62237,
    (ushort) 62209,
    (ushort) 62235,
    (ushort) 62222,
    (ushort) 62213,
    (ushort) 62234,
    (ushort) 62229,
    (ushort) 62217,
    (ushort) 62235,
    (ushort) 62236,
    (ushort) 62224,
    (ushort) 62235,
    (ushort) 62237,
    (ushort) 62234,
    (ushort) 62298,
    (ushort) 62319,
    (ushort) 62319,
    (ushort) 57762,
    (ushort) 57843,
    (ushort) 57740,
    (ushort) 57817,
    (ushort) 57775,
    (ushort) 57778,
    (ushort) 57825,
    (ushort) 57757,
    (ushort) 57796,
    (ushort) 57770,
    (ushort) 57841,
    (ushort) 57822,
    (ushort) 57800,
    (ushort) 57769,
    (ushort) 57783,
    (ushort) 57809,
    (ushort) 57804,
    (ushort) 57827,
    (ushort) 57849,
    (ushort) 57761,
    (ushort) 57799,
    (ushort) 57784,
    (ushort) 49623,
    (ushort) 57812,
    (ushort) 57793,
    (ushort) 57785,
    (ushort) 57834,
    (ushort) 57766,
    (ushort) 57795,
    (ushort) 57823,
    (ushort) 57831,
    (ushort) 57789,
    (ushort) 57808,
    (ushort) 57845,
    (ushort) 57806,
    (ushort) 51040,
    (ushort) 57851,
    (ushort) 57788,
    (ushort) 57829,
    (ushort) 57794,
    (ushort) 57840,
    (ushort) 57773,
    (ushort) 57818,
    (ushort) 57801,
    (ushort) 57780,
    (ushort) 57838,
    (ushort) 57847,
    (ushort) 57771,
    (ushort) 57816,
    (ushort) 57807,
    (ushort) 57779,
    (ushort) 57850,
    (ushort) 57832,
    (ushort) 57798,
    (ushort) 57814,
    (ushort) 57777,
    (ushort) 57837,
    (ushort) 57797,
    (ushort) 57828,
    (ushort) 57819,
    (ushort) 57844,
    (ushort) 57782,
    (ushort) 57802,
    (ushort) 57813,
    (ushort) 57824,
    (ushort) 57772,
    (ushort) 57839,
    (ushort) 57842,
    (ushort) 57787,
    (ushort) 57830
  };
  private IContainer icontainer_0;
  private Button button_0;
  private Label label_0;
  private TextBox textBox_0;
  private Label label_1;

  private static T3 smethod_0<T0, T1, T2, T3>()
  {
    // ISSUE: unable to decompile the method.
  }

  public GForm0()
  {
    this.method_3<ComponentResourceManager, Button, Label, TextBox, string, object, EventArgs, char, ushort, int, Icon>();
  }

  private void method_0<T0, T1>(T0 gparam_0, T1 gparam_1)
  {
  }

  private void method_1<T0, T1, T2, T3, T4, T5>(T1 gparam_0, T2 gparam_1)
  {
    if (string.IsNullOrEmpty(this.textBox_0.Text))
    {
      int num1 = (int) MessageBox.Show(\u003CModule\u003E.smethod_4<string>(2142105182), \u003CModule\u003E.smethod_4<string>(820028934), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    else
    {
      T0 obj1 = (T0) ((string) GForm0.smethod_0<T3, T4, T5, T0>()).Replace(\u003CModule\u003E.smethod_3<string>(-1604884091), \u003CModule\u003E.smethod_3<string>(-1127260429)).TrimEnd((char[]) new T3[1]
      {
        (T3) 10
      });
      if (this.textBox_0.Text.Replace(\u003CModule\u003E.smethod_3<string>(-1604884091), \u003CModule\u003E.smethod_4<string>(736954041)).TrimEnd((char[]) new T3[1]
      {
        (T3) 10
      }) == (string) obj1)
      {
        this.Hide();
        int num2 = (int) MessageBox.Show(\u003CModule\u003E.smethod_5<string>(-960119033), \u003CModule\u003E.smethod_3<string>(-1125437598), MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
        if (num2 == 2)
          Application.Exit();
        if (num2 == 1)
          new GForm1().Show();
        T0 obj2 = (T0) new string(char.MinValue, ((string) obj1).Length);
      }
      else
      {
        int num3 = (int) MessageBox.Show(\u003CModule\u003E.smethod_5<string>(940811979), \u003CModule\u003E.smethod_6<string>(1443628164), MessageBoxButtons.OK, MessageBoxIcon.Hand);
        Application.Exit();
      }
    }
  }

  private void method_2<T0, T1>(T0 gparam_0, T1 gparam_1)
  {
  }

  virtual void Form.Dispose(bool disposing)
  {
    if (disposing && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    // ISSUE: explicit non-virtual call
    __nonvirtual (((Form) this).Dispose(disposing));
  }

  private void method_3<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>()
  {
    // ISSUE: unable to decompile the method.
  }
}
