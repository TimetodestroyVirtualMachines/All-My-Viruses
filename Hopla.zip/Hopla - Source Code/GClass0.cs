﻿// Decompiled with JetBrains decompiler
// Type: GClass0
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

#nullable disable
public static class GClass0
{
  private static readonly string[] string_0 = new string[8]
  {
    \u003CModule\u003E.smethod_4<string>(-1990273348),
    \u003CModule\u003E.smethod_5<string>(-326231187),
    \u003CModule\u003E.smethod_6<string>(-80854747),
    \u003CModule\u003E.smethod_2<string>(-1279055813),
    \u003CModule\u003E.smethod_5<string>(2032426322),
    \u003CModule\u003E.smethod_4<string>(1477506038),
    \u003CModule\u003E.smethod_4<string>(986178720),
    \u003CModule\u003E.smethod_4<string>(325140596)
  };

  internal static T6 smethod_0<T0, T1, T2, T3, T4, T5, T6>()
  {
    // ISSUE: unable to decompile the method.
  }
}
