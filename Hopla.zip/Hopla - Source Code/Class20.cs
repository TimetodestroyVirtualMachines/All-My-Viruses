﻿// Decompiled with JetBrains decompiler
// Type: Class20
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
[CompilerGenerated]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
internal class Class20
{
  private static ResourceManager resourceManager_0;
  private static CultureInfo cultureInfo_0;

  internal Class20()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager_0
  {
    get
    {
      if (Class20.resourceManager_0 == null)
        Class20.resourceManager_0 = new ResourceManager(\u003CModule\u003E.smethod_5<string>(-1348553032), typeof (Class20).Assembly);
      return Class20.resourceManager_0;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo CultureInfo_0
  {
    get => Class20.cultureInfo_0;
    set => Class20.cultureInfo_0 = value;
  }
}
