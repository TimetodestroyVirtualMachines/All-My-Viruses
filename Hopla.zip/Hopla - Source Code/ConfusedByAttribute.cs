﻿// Decompiled with JetBrains decompiler
// Type: ConfusedByAttribute
// Assembly: Hopla, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE498A5B-1A41-4370-AFD2-213D1C256621
// Assembly location: C:\Users\kdap\OneDrive\Documents\Desktop\Hopla.exeCleaned-cleaned_constantsdec_Slayed.exe

using System;

#nullable disable
internal class ConfusedByAttribute : Attribute
{
  public ConfusedByAttribute(string string_0)
  {
  }
}
