Do not even try to run this on your real PC since it'll destroy the boot sector!
Fun fact: ChatGPT made the chemical name of the malware.
Sorry if I copied anybody's scripts, credit to everyone!