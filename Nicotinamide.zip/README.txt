DO NOT RUN THIS ON A REAL PC, EVER!
Nicotinamide by TimetodestroyVirtualMachines
The trojan can disable Task Manager, Registry Editing and much more!