Trojan skid
hx2 8yx.exe is a very bad skid
It's uncool and It's F**king Skidded Anyway.
This is a trojan from 2023.